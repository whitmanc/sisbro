window.tinyMCEPreInit = window.tinyMCEPreInit || {
  base:   '/assets/tinymce',
  query:  '3.4.8',
  suffix: ''
};
